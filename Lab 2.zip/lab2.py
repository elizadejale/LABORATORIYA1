from random import sample
n = int(input("n daxil et: "))
k = int(input("uzunlug daxil et: "))

a = sample(range(1, n+1), k)  # 1 ilə n arasında təsadüfi ədədlərdən ibarət siyahı yaradır
print("Array a:", a)

new_array = [0] * k
for i in range(k):
    new_array[i] = a[i] * 4
print("New Array:", new_array)

sum_greater_than_10 = 0
for i in range(k):
    if new_array[i] > 10:
        sum_greater_than_10 += new_array[i]
print("Cəm:", sum_greater_than_10)
