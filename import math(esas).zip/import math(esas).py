import math

eps = 0.01
x = float(input('x='))
a = float(input('a='))
result = 1  
n = 1
z = 1


while True:
    fakt = (math.log(x) ** n) * z / math.factorial(n)
    
    if abs(fakt) > eps:
        break
    
    result += fakt
    n += 1
    z *= -1 

print('S =', result)

