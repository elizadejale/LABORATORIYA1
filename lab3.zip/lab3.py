import random

# Matrisi yazdıran fonksiyon
def printList(lst):
    for row in lst:
        for item in row:
            print(item, end='    ')
        print()

# NxM boyutunda bir matris oluştur
n, m = 4, 4
a = [[random.randint(10, 20) for _ in range(m)] for _ in range(n)]
print("Başlangıç matrisi:")
printList(a)
print()



# Hər sütunun müsbət elementlərinin hendesi ortasını tapın və baş diaqonala append edin
b = [sum(a[i][j] for i in range(n) if a[i][j] > 0) / sum(1 for i in range(n) if a[i][j] > 0) if sum(1 for i in range(n) if a[i][j] > 0) > 0 else 0 for j in range(m)]
for i in range(n):
    a[i][i] = b[i]

print("Son matris:")
printList(a)
